Ts = 0.1;
[DOF6_Arm,Arminfo] = importrobot('newrobot.mdl');